require('dotenv').config();
const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient({
  datasources: {
    db: {
      url: process.env.DATABASE_URL,
    },
  },
});

async function main() {
  const hashedPassword = await bcrypt.hash('12345', 10);

  console.log('--- Cleaning database ---');
  const tablenames = [
    'Message', 'AnnouncementView', 'Announcement', 'ExamResult', 
    'Option', 'Question', 'Exam', 'Submission', 'Assignment', 
    'MaterialProgress', 'Material', 'UserProgress', 'Appointment', 
    'Enrollment', 'Lesson', 'Course', 'Teacher', 'Account', 'Session', 'User'
  ];

  for (const table of tablenames) {
    try {
      await prisma.$executeRawUnsafe(`TRUNCATE TABLE "${table}" RESTART IDENTITY CASCADE;`);
    } catch (error) {
      const modelName = table.charAt(0).toLowerCase() + table.slice(1);
      if (prisma[modelName]) await prisma[modelName].deleteMany();
    }
  }

  console.log('--- Seeding Users & Teachers ---');

  const fasikaUser = await prisma.user.create({
    data: {
      name: 'Fasika Masersha',
      email: 'fasika@example.com',
      hashedPassword,
      role: 'TEACHER',
      image: 'https://res.cloudinary.com/lamed-english/image/upload/v1771664869/yhzhyrcx2kyphyvstaow.jpg',
      teacherProfile: {
        create: {
          bio: 'Expert English Language Instructor with over 10 years of experience.',
          expertise: ['IELTS', 'Business English', 'Grammar'],
          image: 'https://res.cloudinary.com/lamed-english/image/upload/v1771664869/yhzhyrcx2kyphyvstaow.jpg',
        },
      },
    },
    include: { teacherProfile: true },
  });

  const teachers = [fasikaUser.teacherProfile];
  for (let i = 1; i <= 5; i++) {
    const t = await prisma.user.create({
      data: {
        name: `Teacher ${i}`,
        email: `teacher${i}@test.com`,
        hashedPassword,
        role: 'TEACHER',
        teacherProfile: { create: { bio: `Specialist ${i}`, expertise: ['General English'] } },
      },
      include: { teacherProfile: true },
    });
    teachers.push(t.teacherProfile);
  }

  const students = [];
  for (let i = 1; i <= 20; i++) {
    const s = await prisma.user.create({
      data: { name: `Student ${i}`, email: `student${i}@test.com`, hashedPassword, role: 'USER' },
    });
    students.push(s);
  }

  console.log('--- Seeding Courses & Lessons (Nested Mode) ---');

  for (const teacher of teachers) {
    if (!teacher) continue;
    for (let c = 1; c <= 2; c++) {
      // Using Nested Writes: Creating everything for a course in ONE transaction
      await prisma.course.create({
        data: {
          title: `${teacher.id === fasikaUser.teacherProfile?.id ? 'Advanced Mastery' : 'Course'} ${c}`,
          description: 'Intensive program for fluency.',
          price: 50,
          teacherId: teacher.id,
          category: 'Language',
          level: 'B2',
          lessons: {
            create: Array.from({ length: 4 }).map((_, i) => ({
              title: `Unit ${i + 1}: Theory`,
              content: 'Lesson content goes here.',
              order: i + 1,
              videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
              materials: {
                create: [
                  { title: 'Handout PDF', fileUrl: 'https://example.com/handout.pdf' },
                  { title: 'Guide PDF', fileUrl: 'https://example.com/guide.pdf' }
                ]
              },
              assignments: {
                create: [{ title: 'Final Essay', description: 'Write 500 words.' }]
              },
              exams: {
                create: [{
                  title: 'Certification Exam',
                  duration: 45,
                  questions: {
                    create: [{
                      text: 'Is this the core principle?',
                      options: {
                        create: [
                          { text: 'Yes', isCorrect: true },
                          { text: 'No', isCorrect: false }
                        ]
                      }
                    }]
                  }
                }]
              }
            }))
          }
        }
      });
    }
  }

  console.log('--- Seeding Enrollments & Progress ---');
  const allCourses = await prisma.course.findMany({
    include: { lessons: { include: { assignments: true, materials: true } } }
  });

  for (const student of students) {
    const enrolled = [...allCourses].sort(() => 0.5 - Math.random()).slice(0, 2);
    for (const course of enrolled) {
      const enrollment = await prisma.enrollment.create({
        data: {
          userId: student.id,
          courseId: course.id,
          googleMeetLink: `https://meet.google.com/abc-${student.id.slice(0,3)}`,
          appointments: {
            create: { dayOfWeek: 'Monday', startTime: '02:00 PM' }
          }
        },
      });

      // Grouped progress creation to save connection cycles
      for (const lesson of course.lessons) {
        const isDone = Math.random() > 0.3;
        await prisma.userProgress.create({
          data: { userId: student.id, lessonId: lesson.id, completed: isDone }
        });

        // Seed submissions only for some lessons to avoid overload
        if (lesson.assignments.length > 0 && Math.random() > 0.5) {
          await prisma.submission.create({
            data: {
              userId: student.id,
              assignmentId: lesson.assignments[0].id,
              status: 'SUBMITTED',
              content: 'Work done.'
            }
          });
        }
      }
    }
  }

  console.log('Seed complete! 🚀');
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(async () => { await prisma.$disconnect(); });