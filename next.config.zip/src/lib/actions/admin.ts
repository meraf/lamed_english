"use server"

import { prisma } from "@/lib/prisma";
import { revalidatePath } from "next/cache";

// --- TEACHER MANAGEMENT ---
export async function deleteTeacher(teacherId: string) {
  await prisma.teacher.delete({ where: { id: teacherId } });
  revalidatePath("/admin/teachers");
}

// --- ENROLLMENT & SCHEDULING ---
// Approve enrollment (if you add a status field) or simply set the Meet link
export async function updateStudentSchedule(
  enrollmentId: string, 
  meetLink: string, 
  appointments: { day: string; time: string }[]
) {
  // 1. Update Meet Link
  await prisma.enrollment.update({
    where: { id: enrollmentId },
    data: { googleMeetLink: meetLink }
  });

  // 2. Clear and Replace Appointments
  await prisma.appointment.deleteMany({ where: { enrollmentId } });
  await prisma.appointment.createMany({
    data: appointments.map(app => ({
      enrollmentId,
      dayOfWeek: app.day,
      startTime: app.time
    }))
  });

  revalidatePath("/admin/students");
}

// --- GRADING SYSTEM ---
export async function gradeExam(resultId: string, score: number) {
  await prisma.examResult.update({
    where: { id: resultId },
    data: { score, isGraded: true }
  });
  revalidatePath("/teacher/grading");
}

// --- COURSE & LESSON CRUD ---
export async function deleteLesson(id: string) {
  await prisma.lesson.delete({ where: { id } });
  revalidatePath("/admin/lessons");
}

export async function deleteCourse(id: string) {
  await prisma.course.delete({ where: { id } });
  revalidatePath("/admin/courses");
}

// --- ANNOUNCEMENTS (NEWS) ---
export async function createAnnouncement(courseId: string, title: string, content: string) {
  await prisma.announcement.create({
    data: { courseId, title, content }
  });
  revalidatePath(`/teacher/courses/${courseId}`);
}

