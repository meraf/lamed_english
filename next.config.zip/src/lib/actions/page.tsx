import { prisma } from "@/lib/prisma";
import { Trash2, Edit3, BookOpen, GraduationCap } from "lucide-react";
import { deleteCourse, deleteTeacher } from "@/lib/actions/admin";

export default async function ManageHub() {
  const courses = await prisma.course.findMany({ include: { teacher: { include: { user: true } } } });
  const teachers = await prisma.teacher.findMany({ include: { user: true } });

  return (
    <div className="p-8 space-y-12">
      <h1 className="text-4xl font-black italic">DATABASE MANAGEMENT</h1>

      {/* COURSES TABLE */}
      <section className="bg-white rounded-[2rem] border-4 border-slate-900 overflow-hidden shadow-[12px_12px_0px_0px_rgba(0,0,0,1)]">
        <div className="p-6 bg-slate-900 text-white flex justify-between items-center">
          <h2 className="text-xl font-bold flex items-center gap-2"><BookOpen /> Active Courses</h2>
        </div>
        <table className="w-full text-left">
          <thead>
            <tr className="border-b-4 border-slate-900 bg-slate-50">
              <th className="p-4 font-black uppercase text-xs">Course Title</th>
              <th className="p-4 font-black uppercase text-xs">Instructor</th>
              <th className="p-4 font-black uppercase text-xs text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {courses.map(course => (
              <tr key={course.id} className="border-b-2 border-slate-100 hover:bg-yellow-50 transition-colors">
                <td className="p-4 font-bold">{course.title}</td>
                <td className="p-4 text-slate-500">{course.teacher.user.name}</td>
                <td className="p-4 text-right flex justify-end gap-2">
                  <button className="p-2 hover:bg-slate-200 rounded-lg"><Edit3 size={18}/></button>
                  <form action={async () => { "use server"; await deleteCourse(course.id); }}>
                    <button className="p-2 text-red-500 hover:bg-red-50 rounded-lg"><Trash2 size={18}/></button>
                  </form>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      {/* TEACHERS TABLE */}
      <section className="bg-white rounded-[2rem] border-4 border-slate-900 overflow-hidden shadow-[12px_12px_0px_0px_rgba(0,0,0,1)]">
        <div className="p-6 bg-blue-600 text-white flex justify-between items-center">
          <h2 className="text-xl font-bold flex items-center gap-2"><GraduationCap /> Staff Directory</h2>
        </div>
        <table className="w-full text-left">
          {/* ... similar mapping for teachers using deleteTeacher action ... */}
        </table>
      </section>
    </div>
  );
}