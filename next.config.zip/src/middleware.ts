import { withAuth } from "next-auth/middleware";
import { NextResponse } from "next/server";

export default withAuth(
  function middleware(req) {
    const token = req.nextauth.token;
    const path = req.nextUrl.pathname;

    const isAdmin = token?.role === "ADMIN";
    const isTeacher = token?.role === "TEACHER";

    // 1. Protect Admin routes: Only ADMINs allowed
    if (path.startsWith("/admin") && !isAdmin) {
      return NextResponse.redirect(new URL("/dashboard", req.url));
    }

    // 2. Protect Teacher routes: TEACHERs and ADMINs allowed
    if (path.startsWith("/teacher") && !isTeacher && !isAdmin) {
      return NextResponse.redirect(new URL("/dashboard", req.url));
    }
  },
  {
    callbacks: {
      // This ensures the middleware only runs if a token is present
      authorized: ({ token }) => !!token,
    },
  }
);

export const config = {
  matcher: [
    /*
     * We exclude 'api', '_next/static', '_next/image', and 'favicon.ico'.
     * This prevents the "Unexpected token <" error by making sure the API
     * is never intercepted by this middleware.
     */
    "/((?!api|_next/static|_next/image|favicon.ico).*)",
    
    // Explicitly protect these folders and their sub-paths
    "/admin/:path*",
    "/teacher/:path*",
    "/dashboard/:path*",
    "/learn/:path*",
  ],
};