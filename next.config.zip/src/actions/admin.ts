"use server"
import { prisma } from "@/lib/prisma";
import { revalidatePath } from "next/cache";
import { hash } from "bcrypt";

// --- TEACHERS ---
export async function upsertTeacher(formData: FormData) {
  const id = formData.get("id") as string;
  const name = formData.get("name") as string;
  const email = formData.get("email") as string;
  const image = formData.get("image") as string;
  const bio = formData.get("bio") as string;

  if (id) {
    await prisma.user.update({
      where: { id },
      data: { name, email, image, teacherProfile: { upsert: { create: { bio }, update: { bio } } } }
    });
  } else {
    const hashedPassword = await hash("password123", 10); // Default password
    await prisma.user.create({
      data: { name, email, image, role: "TEACHER", hashedPassword, teacherProfile: { create: { bio } } }
    });
  }
  revalidatePath("/admin/teachers");
}

export async function deleteTeacher(id: string) {
  await prisma.user.delete({ where: { id } });
  revalidatePath("/admin/teachers");
}

// --- COURSES ---
export async function upsertCourse(formData: FormData) {
  const id = formData.get("id") as string;
  const title = formData.get("title") as string;
  const description = formData.get("description") as string;
  const imageUrl = formData.get("imageUrl") as string;
  const teacherId = formData.get("teacherId") as string;

  const data = { title, description, image: imageUrl, teacherId };
  if (id) await prisma.course.update({ where: { id }, data });
  else await prisma.course.create({ data });
  revalidatePath("/admin/courses");
}

export async function deleteCourse(id: string) {
  await prisma.course.delete({ where: { id } });
  revalidatePath("/admin/courses");
}

// --- LESSONS ---
export async function upsertLesson(formData: FormData) {
  const id = formData.get("id") as string;
  const courseId = formData.get("courseId") as string;
  const title = formData.get("title") as string;
  const content = formData.get("content") as string;
  const videoUrl = formData.get("videoUrl") as string;
  const order = parseInt(formData.get("order") as string) || 0;

  const data = { courseId, title, content, videoUrl, order };
  if (id) await prisma.lesson.update({ where: { id }, data });
  else await prisma.lesson.create({ data });
  revalidatePath(`/admin/courses/${courseId}`);
}

export async function deleteLesson(id: string, courseId: string) {
  await prisma.lesson.delete({ where: { id } });
  revalidatePath(`/admin/courses/${courseId}`);
}

// --- EXAMS & ASSIGNMENTS ---
export async function upsertExam(formData: FormData) {
  const id = formData.get("id") as string;
  const lessonId = formData.get("lessonId") as string;
  const title = formData.get("title") as string;
  const timeLimit = parseInt(formData.get("timeLimit") as string);
  const questions = JSON.parse(formData.get("questions") as string); 

  const data = { lessonId, title, duration: timeLimit, questions };
  if (id) await prisma.exam.update({ where: { id }, data });
  else await prisma.exam.create({ data });
  revalidatePath(`/admin/courses/lessons/${lessonId}`);
}

export async function deleteExam(id: string, lessonId: string) {
  await prisma.exam.delete({ where: { id } });
  revalidatePath(`/admin/courses/lessons/${lessonId}`);
}

export async function upsertAssignment(formData: FormData) {
  const id = formData.get("id") as string;
  const lessonId = formData.get("lessonId") as string;
  const title = formData.get("title") as string;
  const description = formData.get("description") as string;

  const data = { lessonId, title, description };
  if (id) await prisma.assignment.update({ where: { id }, data });
  else await prisma.assignment.create({ data });
  revalidatePath(`/admin/courses/lessons/${lessonId}`);
}

export async function deleteAssignment(id: string, lessonId: string) {
  await prisma.assignment.delete({ where: { id } });
  revalidatePath(`/admin/courses/lessons/${lessonId}`);
}

// --- GRADING ---
export async function gradeSubmission(id: string, grade: number, type: 'EXAM' | 'ASSIGNMENT') {
  if (type === 'ASSIGNMENT') {
    await prisma.submission.update({ where: { id }, data: { score: grade, status: "GRADED" } });
  } else {
    await prisma.examResult.update({ where: { id }, data: { score: grade, isGraded: true } });
  }
  revalidatePath("/admin/grading");
}

// --- MEET LINKS & SCHEDULES ---
export async function updateMeetLink(enrollmentId: string, meetLink: string, courseId: string) {
  // FIX: Changed 'googleMeet' to 'googleMeetLink' to match your Prisma schema
  await prisma.enrollment.update({ 
    where: { id: enrollmentId }, 
    data: { googleMeetLink: meetLink } 
  });
  revalidatePath(`/admin/courses/${courseId}`);
}

export async function upsertAppointment(formData: FormData) {
  const id = formData.get("id") as string;
  const enrollmentId = formData.get("enrollmentId") as string;
  const courseId = formData.get("courseId") as string;
  const dayOfWeek = formData.get("dayOfWeek") as string;
  const startTime = formData.get("startTime") as string;

  const data = { enrollmentId, dayOfWeek, startTime };
  if (id) await prisma.appointment.update({ where: { id }, data });
  else await prisma.appointment.create({ data });
  revalidatePath(`/admin/courses/${courseId}`);
}

export async function deleteAppointment(id: string, courseId: string) {
  await prisma.appointment.delete({ where: { id } });
  revalidatePath(`/admin/courses/${courseId}`);
}